jQuery(document).ready(function($) {
var curdir = $('#sudoku_wp_div .sudoku_wp_inp_curdir').val();
var div = $('#sudoku_wp_div');
var opts = $('#sudoku_wp_div .sudoku_wp_inp_param').val();
var hold = $('#sudoku_wp_div img');

//$('#sudoku_wp_div').html('<hr /><p>senza ajax opts = '+opts+'</p><hr />');return;

$.ajax({
url: curdir+'generate.php',
data: 'opts='+opts,
dataType: 'html',
type: 'GET',
beforeSend: function(a){ hold.show() }, 
error: function(a,b,c){alert('Error loading script');}, 
success: function(a,b){
div.html(a);

var s_bus = $('#div_php_wp_plugin_sudoku button');
var s_inp = $('#div_php_wp_plugin_sudoku input:visible');
s_inp.keypress(function() {$(this).css('color','black');});
s_inp.each(function(i) { $(this).val('') });
s_bus.eq(0).click(function() {
$(this).blur();
s_inp.each(function(i) {
var v_u = $(this).val();
var v_p = $(this).siblings().eq(0).val();
if (v_u != '') {
if (v_u == v_p) { $(this).css('color','lightgreen') } else { $(this).css('color','red') }
}
});
});
s_bus.eq(1).click(function() {
$(this).blur();
if ( confirm('Are you sure to see the solution?') ) {
s_inp.each(function(i) {
var v_p = $(this).siblings().eq(0).val();
var cell = $(this).parent().eq(0);
$(this).hide();
cell.text(v_p);
});
s_bus.eq(0).hide();
s_bus.eq(1).hide();
}
});


}, // success
complete: function(a,b){ hold.hide() } 
});

});