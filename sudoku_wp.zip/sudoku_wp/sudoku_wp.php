<?php
/*
Plugin Name: Sudoku for Wordpress 
Plugin URI: http://oreste.parlatano.org/wp/?p=64
Description: include a sudoku grid ready to play in a page or article with the following code [sudoku_wp options]
Author: Oreste Parlatano
Version: 1.0
Author URI: http://oreste.parlatano.org
*/   
   
/*  Copyright 2011  
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the i= mplied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
Options
holes:  number of holes per row (min 2, max 6)
colo:   colour of sudoku numbers
back0:  background colour of sudoku table
fsiz:   size of sudoku numbers in pixels
ffam:   font-family of sudoku numbers
side:   physical size of sudoku 9×9 square plus buttons in pixels
bucol:  colour of buttons font
buback: colour of buttons background
bumar:  margin left of buttons
*/
#---------------------------------------------------------------------------------------------------
if(! class_exists('sudoku_by_Oreste_Parlatano')) {
class sudoku_by_Oreste_Parlatano {
#---------------------------------------------------------------------------------------------------
function sudoku_wp_replace_tag($text) {
$plugin_sub_dir = plugins_url().'/sudoku_wp/sub/';
$altropat = '/(?P<sopra>.*)(?P<griglia>\[sudoku_wp)(?P<parametri>.*)\](?P<sotto>.*)/s';
$ret = $text;
if (preg_match($altropat,$text,$match) > 0)
$ret = '<div id="sudoku_wp_div">'.
'<img src="'.$plugin_sub_dir.'progress.gif" alt="wait" style="display:none" />'.
'<input class="sudoku_wp_inp_param" type="hidden" value="'.$match[parametri].'">'.
'<script type="text/javascript" src="'.$plugin_sub_dir.'sudoku_wp.js"></script>'.
'<input class="sudoku_wp_inp_curdir" type="hidden" value="'.$plugin_sub_dir.'" />'.
'</div><br />';


return $ret;
}
#-------------------------------------------------------------------------------------------------------------
}
}
#---------------------------------------------------------------------------------------------------
if(class_exists('sudoku_by_Oreste_Parlatano')) {
$vai_con_il_sudoku = new sudoku_by_Oreste_Parlatano();
}
#---------------------------------------------------------------------------------------------------
if(isset($vai_con_il_sudoku)) {
add_filter('the_content',array(&$vai_con_il_sudoku,'sudoku_wp_replace_tag'));
}
#---------------------------------------------------------------------------------------------------
?>